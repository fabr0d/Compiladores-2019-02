Profesor, funciona perfecto, con el ejemplo que envio y otros. 
Se puede omitir algunos calculos, como comentar los tmp que ya no son necesarios. 
Y aquellos if que los llaman cambiarles la logica. Ello daria menor costo computacional.