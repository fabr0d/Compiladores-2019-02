#include <iostream>
#include <string>
#include <regex>
using namespace std;

void isip(string cadena)
{
	regex r("[1-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}");
	if( regex_match(cadena, r) )
		cout <<"SI ES UNa ip"<<endl;
	else
		cout << "NO ES UNa ip" <<endl;
}

void isvarname(string cadena)
{
	regex r("([a-z][0-9]*|[A-Z][0-9]*|(\\_[0-9]*))+");
	if( regex_match(cadena, r) )
		cout <<"Es un nombre de la cadena"<<endl;
	else
		cout << "No es un nombre de la cadena" <<endl;
}

int main() {
	string cadena;
	cin>>cadena;
	isip(cadena);
	isvarname(cadena);
	return 0;
}